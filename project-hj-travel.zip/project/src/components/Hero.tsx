import React from 'react';
import { CaretDown } from '@phosphor-icons/react';

export default function Hero() {
  return (
    <div id="accueil" className="relative h-screen">
      <div 
        className="absolute inset-0 bg-cover bg-center"
        style={{
          backgroundImage: 'url("https://www.voyageursdumonde.fr/voyage-sur-mesure/magazine-voyage/ShowPhoto/1483/0")',
        }}
      >
        <div className="absolute inset-0 bg-black/40" />
      </div>
      
      <div className="relative h-full flex flex-col items-center justify-center text-center text-white px-4">
        <h1 className="text-5xl md:text-6xl font-bold mb-6">Découvrez la Tunisie</h1>
        <p className="text-xl md:text-2xl mb-8 max-w-2xl">
          Explorez les trésors cachés de la Méditerranée avec notre expertise locale
        </p>
        <button className="bg-teal-600 hover:bg-teal-700 text-white font-bold py-3 px-8 rounded-full transition duration-300">
          Réserver Maintenant
        </button>
        
        <a href="#destinations" className="absolute bottom-8 animate-bounce">
          <CaretDown size={32} />
        </a>
      </div>
    </div>
  );
}