import React from 'react';
import { Coffee, Users, Calendar, MapPin } from '@phosphor-icons/react';

const services = [
  {
    icon: <MapPin size={32} weight="fill" />,
    title: 'Circuits Guidés',
    description: 'Découvrez les plus beaux sites touristiques de la Tunisie'
  },
  {
    icon: <Coffee size={32} weight="fill" />,
    title: 'Séjours Personnalisés',
    description: 'Créez votre voyage sur mesure selon vos envies et votre budget'
  },
  {
    icon: <Users size={32} weight="fill" />,
    title: 'Guides Locaux',
    description: 'Accompagnement par des guides expérimentés et passionnés'
  },
  {
    icon: <Calendar size={32} weight="fill" />,
    title: 'Excursions',
    description: 'Large choix d\'excursions et d\'activités culturelles'
  }
];

export default function Services() {
  return (
    <section id="services" className="py-20 bg-white">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="text-center mb-16">
          <h2 className="text-4xl font-bold text-gray-900 mb-4">Nos Services</h2>
          <p className="text-xl text-gray-600">Une expérience de voyage complète et personnalisée</p>
        </div>
        
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-8">
          {services.map((service, index) => (
            <div key={index} className="text-center p-6 rounded-lg bg-gray-50 hover:bg-gray-100 transition-colors duration-300">
              <div className="inline-flex items-center justify-center w-16 h-16 rounded-full bg-teal-100 text-teal-600 mb-6">
                {service.icon}
              </div>
              <h3 className="text-xl font-semibold text-gray-900 mb-2">{service.title}</h3>
              <p className="text-gray-600">{service.description}</p>
            </div>
          ))}
        </div>
      </div>
    </section>
  );
}