import React from 'react';

const destinations = [
  {
    title: 'Sidi Bou Said',
    image: 'https://www.guidesulysse.com/images/destinations/iStock-498116298.jpg',
    description: 'Village pittoresque aux maisons bleues et blanches surplombant la Méditerranée.'
  },
  {
    title: 'Djerba',
    image: 'https://dynamic-media-cdn.tripadvisor.com/media/photo-o/1a/77/63/9b/robinson-club-djerba.jpg?w=700&h=-1&s=1',
    description: 'Île paradisiaque aux plages de sable fin et architecture traditionnelle.'
  },
  {
    title: 'Sahara',
    image: 'https://www.allibert-trekking.com/iconographie/f1/PA1_desert-tunisien.jpg',
    description: 'Aventures inoubliables dans les dunes dorées du désert.'
  }
];

export default function Destinations() {
  return (
    <section id="destinations" className="py-20 bg-gray-50">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="text-center mb-16">
          <h2 className="text-4xl font-bold text-gray-900 mb-4">Destinations Populaires</h2>
          <p className="text-xl text-gray-600">Découvrez nos destinations les plus prisées</p>
        </div>
        
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-8">
          {destinations.map((destination, index) => (
            <div key={index} className="bg-white rounded-lg overflow-hidden shadow-lg transition-transform duration-300 hover:scale-105">
              <div className="relative h-64">
                <img
                  src={destination.image}
                  alt={destination.title}
                  className="w-full h-full object-cover"
                />
              </div>
              <div className="p-6">
                <h3 className="text-xl font-semibold text-gray-900 mb-2">{destination.title}</h3>
                <p className="text-gray-600">{destination.description}</p>
                <button className="mt-4 text-teal-600 font-semibold hover:text-teal-700">
                  En savoir plus →
                </button>
              </div>
            </div>
          ))}
        </div>
      </div>
    </section>
  );
}